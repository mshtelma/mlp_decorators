class DecoratedFunctions:
    functions = {}

    @staticmethod
    def clean():
        DecoratedFunctions.functions.clear()


def estimator_method(func):
    """
    estimator_method decorator.

    :param name:
    :return:
    """
    DecoratedFunctions.functions["train"] = func

    def wrapper():
        return func()

    return wrapper


def transformer_method(func):
    """
    transformer_method decorator.

    :param name:
    :return:
    """
    DecoratedFunctions.functions["transform"] = func

    def wrapper():
        return func()

    return wrapper
